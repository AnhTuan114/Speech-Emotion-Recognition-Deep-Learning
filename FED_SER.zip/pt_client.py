import warnings
import flwr as fl
import numpy as np
from sklearn.metrics import log_loss
import utils
from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout


if __name__ == "__main__":
    # Load MNIST dataset from https://www.openml.org/d/554
    (X_train, y_train), (X_test, y_test),X = utils.load_mnist()

    # Split train set into 10 partitions and randomly use one for training.
    partition_id = np.random.choice(10)
    (X_train, y_train) = utils.partition(X_train, y_train, 10)[partition_id]

    # Create LogisticRegression Model
    model = Sequential([
    LSTM(64, return_sequences = True, input_shape=(X.shape[1:3])),
    LSTM(64),
    Dense(8, activation='softmax')
    ])
   


    # Setting initial parameters, akin to model.compile for keras models
    #cập nhật tham số vào mô hìnhq
    utils.set_initial_params(model)

    # Define Flower client
    class Client(fl.client.NumPyClient):
        def get_parameters(self, config):  # type: ignore #config các tham số cấu honhfmáy chủ yêu cầu. Báo cho client :tham số cần thiết ,thuộc tính vô hướng
            return utils.get_model_parameters(model)#Tham số mô hình cục bộ dưới dạng danh sách nd.arrays
#config: tham số cấu hình cho phép của máy chủ: truyền giá trị tùy ý từ máy chủ đến máy khách VD: epoch: nút
        def fit(self, parameters, config):  # parameter: tham số mô hình toàn cầu hiện tại, 
            utils.set_model_params(model, parameters)
            # Ignore convergence failure due to low local epochs
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
                model.fit(X_train, y_train, validation_split=0.2, epochs=200, batch_size=23)
            print(f"Training finished for round {config['server_round']}")
            return utils.get_model_parameters(model), len(X_train), {}

            
        # def evaluate(self, parameters, config):  # đánh giá mô hình
        #     utils.set_model_params(model, parameters)
        #     accuracy =model.model['accuracy']
        #     return loss, len(X_test), {"accuracy": accuracy}
        # Start Flower client
    fl.client.start_numpy_client(server_address="localhost:8080", client=Client())#khởi động flower NumpyClient/ MnistClient: lớp cơ sở trừu tượng