from typing import Tuple, Union, List
import numpy as np
from json_tricks import dump, load
from keras.models import Sequential
from sklearn.model_selection import train_test_split
import tensorflow as tf

XY = Tuple[np.ndarray, np.ndarray]
Dataset = Tuple[XY, XY]
LogRegParams = Union[XY, Tuple[np.ndarray]]
XYList = List[XY]

Params = Union[XY, Tuple[np.ndarray]]


def get_model_parameters(model: Sequential) -> LogRegParams: #trả về tham số mô hình cục bộ
    """Returns the paramters of a sklearn LogisticRegression model."""
    params = [
            model.coef_,
        ]
    return params

def set_model_params(       #khởi tạo tham số cho mô hình
    model: Sequential, params: LogRegParams
) -> Sequential:
    """Sets the parameters of a sklean LogisticRegression model."""
    model.coef_ = params[0]
    return model



def set_initial_params(model: Sequential): #cập nhật tham số
    """Sets initial parameters as zeros Required since model params are
    uninitialized until model.fit is called.
    But server asks for initial parameters from clients at launch. Refer
    to sklearn.linear_model.LogisticRegression documentation for more
    information.
    """
    n_classes = 7  # MNIST has 10 classes
    n_features = 257  # Number of features in dataset
    model.classes_ = np.array([i for i in range(7)])
    model.coef_ = np.zeros((n_classes, n_features))

def load_mnist() -> Dataset:
    x_path = 'D:\HỌC MÁY THỐNG KÊ\Project - Copy\Fed_Mal_Det\demo\X_datanew.json' # FILE LOAD PATH
    X = load(x_path)
    X = np.asarray(X, dtype = 'float32')

    y_path = 'D:\HỌC MÁY THỐNG KÊ\Project - Copy\Fed_Mal_Det\demo\Y_datanew.json'
    Y = load(y_path)
    Y = np.asarray(Y, dtype = 'int8')   
    
    x_train, x_tosplit, y_train, y_tosplit = train_test_split(X, Y, test_size = 0.125, random_state = 1)
    x_val, x_test, y_val, y_test = train_test_split(x_tosplit, y_tosplit, test_size = 0.304, random_state = 1)

#'One-hot' vectors for Y: emotion classification
    y_train_class = tf.keras.utils.to_categorical(y_train, 8, dtype = 'int8')
    y_val_class = tf.keras.utils.to_categorical(y_val, 8, dtype = 'int8')
    
    return (x_train, y_train_class), (x_val, y_val_class),X

def partition(X: np.ndarray, y: np.ndarray, num_partitions: int) -> XYList: #phân chia dữu liệu
    """Split X and y into a number of partitions."""
    return list(
        zip(np.array_split(X, num_partitions), np.array_split(y, num_partitions))
    )
x_path = 'D:\HỌC MÁY THỐNG KÊ\Project - Copy\Fed_Mal_Det\demo\X_datanew.json' # FILE LOAD PATH
X = load(x_path)
X = np.asarray(X, dtype = 'float32')

y_path = 'D:\HỌC MÁY THỐNG KÊ\Project - Copy\Fed_Mal_Det\demo\Y_datanew.json'
Y = load(y_path)
Y = np.asarray(Y, dtype = 'int8')   

x_train, x_tosplit, y_train, y_tosplit = train_test_split(X, Y, test_size = 0.125, random_state = 1)
x_val, x_test, y_val, y_test = train_test_split(x_tosplit, y_tosplit, test_size = 0.304, random_state = 1)

#'One-hot' vectors for Y: emotion classification
y_train_class = tf.keras.utils.to_categorical(y_train, 8, dtype = 'int8')
y_val_class = tf.keras.utils.to_categorical(y_val, 8, dtype = 'int8')
print(X.shape, Y.shape, x_val.shape,y_val.shape,x_train.shape,y_train_class.shape)